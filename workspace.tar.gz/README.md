# MRJ
My Resume with Django
